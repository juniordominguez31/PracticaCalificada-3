package logistica;

import java.util.*; 

public class GrafoRutas {
    private final Map<String, LinkedList<Ruta>> adyacencia = new HashMap<>();

    public void agregarCiudad(String ciudad) {
        adyacencia.putIfAbsent(ciudad, new LinkedList<>());
    }

    public boolean existeCiudad(String ciudad) {
        return adyacencia.containsKey(ciudad);
    }

    public void agregarRuta(String origen, String destino, int km) {
        if (!adyacencia.containsKey(origen) || !adyacencia.containsKey(destino)) {
            return;
        }
        adyacencia.get(origen).add(new Ruta(destino, km));
        adyacencia.get(destino).add(new Ruta(origen, km));
    }

    public String mostrarRutas() {
        StringBuilder sb = new StringBuilder();
        for (String origen : adyacencia.keySet()) {
            sb.append(origen).append(" -> ");
            for (Ruta r : adyacencia.get(origen)) {
                sb.append(r).append("  ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public List<String> bfs(String inicio) {
        List<String> visitados = new ArrayList<>();
        if (!adyacencia.containsKey(inicio)) {
            return visitados;
        }

        Queue<String> cola = new LinkedList<>();
        Set<String> vistos = new HashSet<>();
        cola.add(inicio);
        vistos.add(inicio);

        while (!cola.isEmpty()) {
            String actual = cola.poll();
            visitados.add(actual);
            for (Ruta r : adyacencia.get(actual)) {
                if (!vistos.contains(r.getDestino())) {
                    vistos.add(r.getDestino());
                    cola.add(r.getDestino());
                }
            }
        }
        return visitados;
    }

    public int distanciaRuta(List<String> camino) {
        int total = 0;
        for (int i = 0; i < camino.size() - 1; i++) {
            String origen = camino.get(i);
            String destino = camino.get(i + 1);
            for (Ruta r : adyacencia.getOrDefault(origen, new LinkedList<>())) {
                if (r.getDestino().equals(destino)) {
                    total += r.getDistanciaKm();
                    break;
                }
            }
        }
        return total;
    }
}
